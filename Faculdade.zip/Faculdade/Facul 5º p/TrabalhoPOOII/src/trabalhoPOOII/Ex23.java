package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
23. Fa�a um algoritmo que receba um n�mero e mostre uma mensagem caso este n�mero sege maior que 80, menor
que 25 ou igual a 40.

*/

public class Ex23 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int num;

		 System.out.println("Digite um numero: ");
		 num = escreva.nextInt();

		 if(num > 80){
			 System.out.println("\nEste numero eh maior que 80!");
		 }
		 else if(num < 25){
			 System.out.println("\nEste numero eh menor que 25!");
		 }
		 else if(num == 40){
			 System.out.println("\nEste numero eh igual a 40!");
		 }
		 else{
			 System.out.println("N�o est� dentro do intervalo!");
		 }

	}

}