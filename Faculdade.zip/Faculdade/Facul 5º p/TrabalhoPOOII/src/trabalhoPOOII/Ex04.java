package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
4. Escrever um algoritmo que leia o nome de um vendedor, o seu sal�rio fixo e o total de vendas efetuadas por ele no
m�s (em dinheiro). Sabendo que este vendedor ganha 15% de comiss�o sobre suas vendas efetuadas, informar o
seu nome, o sal�rio fixo e sal�rio no final do m�s.

*/

public class Ex04 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		String nome;
		float salario, vendas, totalvendas, salarioTotal;

		System.out.println("Digite o nome do vendedor: ");
		nome = escreva.next();
		System.out.println("Digite o seu salario: ");
		salario = escreva.nextFloat();
		System.out.println("Digite o total de vendas em dinheiro: ");
		vendas = escreva.nextInt();

		totalvendas = (float) (vendas * 0.15);
		salarioTotal = salario + totalvendas;

		System.out.println("\nO nome do vendedor eh: " + nome);
		System.out.println("O salario fixo do vendedor eh: " + salario);
		System.out.println("O salario total do vendedor eh: " + salarioTotal);

	}

}