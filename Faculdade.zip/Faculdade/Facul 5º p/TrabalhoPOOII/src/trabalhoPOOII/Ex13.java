package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
13. Fa�a um algoritmo que receba um n�mero e mostre uma mensagem caso este n�mero seja maior que 10.
*/

public class Ex13 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int num;

		System.out.println("Digite um numero: ");
		num = escreva.nextInt();

		if(num > 10){
			System.out.println("\nEste numero eh maior que 10!");
		} else{
			System.out.println("...");
		}

	}

}