package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
33. Escrever um algoritmo que leia tr�s valores inteiros e verifique se eles podem ser os lados de um tri�ngulo. Se
forem, informar qual o tipo de tri�ngulo que eles formam: equil�tero, is�scele ou escaleno.
Propriedade: o comprimento de cada lado de um tri�ngulo � menor do que a soma dos comprimentos dos outros
dois lados.
Tri�ngulo Equil�tero: aquele que tem os comprimentos dos tr�s lados iguais;
Tri�ngulo Is�scele: aquele que tem os comprimentos de dois lados iguais. Portanto, todo tri�ngulo equil�tero �
tamb�m is�scele;
Tri�ngulo Escaleno: aquele que tem os comprimentos de seus tr�s lados diferentes.
*/

public class Ex33 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int num1, num2, num3;

		 System.out.println("Digite o primeiro valor: ");
		 num1 = escreva.nextInt();
		 System.out.println("Digite o segundo valor: ");
		 num2 = escreva.nextInt();
		 System.out.println("Digite o terceiro valor: ");
		 num3 = escreva.nextInt();

		 if ((num1 < (num2 + num3))&&(num2 < (num1 + num3))&&(num3 < (num2 + num1))){
		    if((num1 == num2)&&(num1 == num3)&&(num2 == num3)){
		    	System.out.println("\nForma os lados de um: ");
		    	System.out.println("-> Triangulo Equilatero!");
		    }
		    else if((num1 == num2)||(num1 == num3)||(num2 == num3)){
		    	System.out.println("\nForma os lados de um: ");
		    	System.out.println("-> Triangulo Isosceles!");
		    }
		    else if((num1 != num2)&&(num1 != num3)&&(num2 != num3)){
		    	System.out.println("\nForma os lados de um: ");
		    	System.out.println("-> Triangulo Escaleno!");
		    }
		 }else{
			 System.out.println("\nNao forma os lados de um triangulo! :/");
		 }

	}

}