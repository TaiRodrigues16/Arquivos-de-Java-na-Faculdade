package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
35. Elabore um algoritmo que, dada a idade de um nadador. Classifique-o em uma das seguintes categorias:
Infantil A = 5 - 7 anos
Infantil B = 8 - 10 anos
juvenil A = 11- 13 anos
juvenil B = 14 - 17 anos
S�nior = 18 - 25 anos
Apresentar mensagem �idade fora da faixa et�ria� quando for outro ano n�o contemplado.

*/

public class Ex35 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int idade;

		 System.out.println("Digite a idade do nadador: ");
		 idade = escreva.nextInt();

		 if((idade >= 5)&&(idade <= 7)){
			 System.out.println("\nCategoria: Infantil A!");
		 }
		 else if((idade >= 8)&&(idade <= 10)){
			 System.out.println("\nCategoria: Infantil B!");
		 }
		 else if((idade >= 11)&&(idade <= 13)){
			 System.out.println("\nCategoria: Juvenil A!");
		 }
		 else if((idade >= 14)&&(idade <= 17)){
			 System.out.println("\nCategoria: Juvenil B!");
		 }
		 else if((idade >= 18)&&(idade <= 25)){
			 System.out.println("\nCategoria: Senior!");
		 }
		 else{
			 System.out.println("\nIdade fora da faixa etaria!");
		 }	
	}
}