package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
15. Fa�a um algoritmo que receba um n�mero e diga se este n�mero est� no intervalo entre 100 e 200.
*/

public class Ex15 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int num;

		System.out.println("Digite um numero: ");
		num = escreva.nextInt();

		if((num >= 100)&&(num <= 200)){
			System.out.println("\nEste numero esta no intervalo entre 100 e 200!");
		}else{
			System.out.println("\nEste numero n�o esta no intervalo!");
		}

	}

}