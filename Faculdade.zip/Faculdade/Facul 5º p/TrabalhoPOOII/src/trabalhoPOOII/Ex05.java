package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
5. Escrever um algoritmo que leia o nome de um aluno e as notas das tr�s provas que ele obteve no semestre. No final
informar o nome do aluno e a sua m�dia (aritm�tica).

*/

public class Ex05 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		String nome;
		float nota1,nota2,nota3,media;

		System.out.println("Digite o nome do aluno: ");
		nome = escreva.next();
		System.out.println("Digite a nota da primeira prova: ");
		nota1 = escreva.nextFloat();
		System.out.println("Digite a nota da segunda prova: ");
		nota2 = escreva.nextFloat();
		System.out.println("Digite a nota da terceira prova: ");
		nota3 = escreva.nextFloat();

		media = (nota1 + nota2 + nota3)/3;

		System.out.println("\nO nome do aluno eh: " + nome);
		System.out.println("A sua media eh de: " + media);

	}

}