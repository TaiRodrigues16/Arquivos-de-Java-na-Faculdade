package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
16. Escrever um algoritmo que leia o nome e as tr�s notas obtidas por um aluno durante o semestre. Calcular a sua
m�dia (aritm�tica), informar o nome e sua men��o aprovado (media >= 7), Reprovado (media <= 5) e Recupera��o
(media entre 5.1 a 6.9).
*/

public class Ex16 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		String nome;
		float nota1,nota2,nota3,media;

		System.out.println("Digite o nome do aluno: ");
		nome = escreva.next();

		System.out.println("Digite a primeira nota obtida no semestre: ");
		nota1 = escreva.nextFloat();
		System.out.println("Digite a segunda nota obtida no semestre: ");
		nota2 = escreva.nextFloat();
		System.out.println("Digite a terceira nota obtida no semestre: ");
		nota3 = escreva.nextFloat();

		media = (nota1 + nota2 + nota3) / 3;

		if(media >= 7){
			System.out.println("\nO aluno(a) " + nome + " foi APROVADO!");
		}

		else if(media <= 5){
			System.out.println("\nO aluno(a) " + nome + " foi REPROVADO!");
		}

		else if((media > 5.1) && (media < 6.9)){
			System.out.println("\nO aluno(a) " + nome + " esta de RECUPERA��O!");
		}

	}
}