package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
22. Fa�a um algoritmo que receba o pre�o de custo e o pre�o de venda de 40 produtos. Mostre como resultado se
houve lucro, preju�zo ou empate para cada produto. Informe media de pre�o de custo e do pre�o de venda.
*/

public class Ex22 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float precoCusto = 0, precoVenda = 0,soma1,soma;
		int i;

		soma1 = precoCusto;
		soma = precoVenda;

		for(i=0;i<40;i++){
		     System.out.println("Digite o preco de custo do produto: ");
		     precoCusto = escreva.nextFloat();
		     System.out.println("Digite o preco de venda: ");
		     precoVenda = escreva.nextFloat();

		     if(precoCusto < precoVenda){
		    	 System.out.println("\nHouve lucro!\n");
		         soma1 = soma1 + precoCusto;
		         soma = soma + precoVenda;
		     }
		     else if(precoCusto == precoVenda){
		    	 System.out.println("\nHouve empate!\n");
		         soma1 = soma1 + precoCusto;
		         soma = soma + precoVenda;
		     }
		     else if(precoCusto > precoVenda){
		    	 System.out.println("\nHouve prejuizo!\n");
		         soma1 = soma1 + precoCusto;
		         soma = soma + precoVenda;
		     }

		 }

		System.out.println("A media de Preco de Custo eh: " + (soma1/40));
		System.out.println("A media de Preco de Venda eh: " + (soma/40));

	}

}