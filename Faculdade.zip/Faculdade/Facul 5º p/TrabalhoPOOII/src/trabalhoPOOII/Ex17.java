package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
17. Ler 80 n�meros e ao final informar quantos n�mero(s) est(�)�o no intervalo entre 10 (inclusive)
e 150 (inclusive).
*/

public class Ex17 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int i,num,cont;

		cont = 0;

		for(i=0;i<80;i++){
			System.out.println("Digite um numero: ");
			num = escreva.nextInt();

			if ((num>=10) && (num<=150)){
				cont++;
			}
		}

		System.out.println("\nS�o " + cont + " numeros!");

	}

}