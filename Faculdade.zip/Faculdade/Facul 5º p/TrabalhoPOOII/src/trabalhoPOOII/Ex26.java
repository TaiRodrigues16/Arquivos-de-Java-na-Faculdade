package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
26. Fa�a um algoritmo que leia um n�mero de 1 a 5 e escreva por extenso. Caso o usu�rio digite um n�mero que n�o
esteja neste intervalo, exibir mensagem: n�mero inv�lido.

*/

public class Ex26 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int num;

		 System.out.println("Digite um numero: ");
		 num = escreva.nextInt();

		 if(num == 1){
			 System.out.println("\nNumero: Um");
		 }
		 else if(num == 2){
			 System.out.println("\nNumero: Dois");
		 }
		 else if(num == 3){
			 System.out.println("\nNumero: Tres");
		 }
		 else if(num == 4){
			 System.out.println("\nNumero: Quatro");
		 }
		 else if(num == 5){
			 System.out.println("\nNumero: Cinco");
		 }else{
			 System.out.println("\nNumero Invalido!");
		 }

	}
}