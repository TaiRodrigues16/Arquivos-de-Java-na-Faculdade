package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
1. Fa�a um algoritmo que receba dois n�meros e exiba o resultado da sua soma.
*/

public class Ex01 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float num1,num2, result;

		System.out.println("Digite o primeiro numero: \n");
		num1 = escreva.nextFloat();
		System.out.println("Digite o segundo numero: \n\n");
		num2 = escreva.nextFloat();

		result = num1 + num2;

		System.out.println("\n\nO resultado da soma eh: " + result);

	}

}