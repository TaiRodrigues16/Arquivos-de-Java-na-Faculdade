package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
21. Escrever um algoritmo que leia os dados de �N� pessoas (nome, sexo, idade e sa�de) e informe se est� apta ou n�o
para cumprir o servi�o militar obrigat�rio. Informe os totais.

*/

public class Ex21 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int idade,prog,cont, apto, totalApto, total;
		String nome,sexo,saude, opc;
		
		totalApto = 0;
		total = 0;
		prog = 1;
		 
		while(prog == 1){
			apto = 1;
			saude = "b";
			total = total + 1;
			System.out.println("Digite o nome da pessoa: ");
		    nome = escreva.next();
		    System.out.println("Digite o sexo da pessoa (F/M): ");
		    sexo = escreva.next();
		    System.out.println("Digite a idade da pessoa: ");
		    idade = escreva.nextInt();
		    
		    if(idade < 18){
		    	apto = 0;
		    }
		    
		    System.out.println("Digite saude da pessoa:");
		    System.out.println("B -> Boa");
		    System.out.println("R -> Ruim");
		    saude = escreva.next();
		     
		    switch (saude) {
			case "r":
				saude = "r";
				apto = 0;
				break;

			default:
				saude = "b";
				break;
			}
		    
		    if (apto == 1) {
				totalApto = totalApto + 1;
			}
		    
		    if ((idade>=18) && (saude == "b")) {
		    	System.out.println("Est� Atpa!");
			}else{
				System.out.println("N�o est� Atpa!");
			}
		    
		    System.out.println("Deseja continuar acrescentando mais pessoas? (S/N)");
		    opc = escreva.next();
		    
		    switch (opc) {
			case "n":
				opc = "n";
				prog = 0;
				break;

			default:
				break;
			}
    
		 }

		 System.out.println("\nSao " + totalApto + " pessoa aptas!");
		 System.out.println("\nA quantidade de pessoas Nao aptas eh: " + (total-totalApto));

	}

}