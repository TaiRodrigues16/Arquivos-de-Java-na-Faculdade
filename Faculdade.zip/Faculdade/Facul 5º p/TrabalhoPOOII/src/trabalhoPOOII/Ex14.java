package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
14. Escrever um algoritmo que leia dois valores inteiro distintos e informe qual � o maior.
*/


public class Ex14 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int num1, num2;

		System.out.println("Digite o primeiro numero: ");
		num1 = escreva.nextInt();

		System.out.println("Digite o segundo numero: ");
		num2 = escreva.nextInt();

		if(num1 > num2){
			System.out.println("\nO numero " + num1 + " eh maior que "+ num2 +  " !");
		}
		else if(num2 > num1){
			System.out.println("\nO numero "+ num2 + " eh maior que " + num1 + " !");
		}
		else{
			System.out.println("\nOs numeros sao iguais!!!");
		}

	}

}