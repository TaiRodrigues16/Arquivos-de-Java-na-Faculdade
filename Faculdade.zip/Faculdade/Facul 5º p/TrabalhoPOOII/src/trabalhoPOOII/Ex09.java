package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
9. Fa�a um algoritmo que receba um valor que foi depositado e exiba o valor com rendimento ap�s um m�s.
Considere fixo o juro da poupan�a em 0,70% a. m.
mensais = 0,058 ou aproximadamente 0,06
*/

public class Ex09 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float valorDep, valorRend;

		System.out.println("Digite o valor depositado: ");
		valorDep = escreva.nextFloat();

		valorRend = (float) (valorDep + (valorDep * 0.058));

		System.out.println("\nO valor com o rendimento eh de: " + valorRend);

	}

}