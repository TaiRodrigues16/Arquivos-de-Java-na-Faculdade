package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
18. Fa�a um algoritmo que receba a idade de 75 pessoas e mostre mensagem informando "maior de idade" e "menor de
idade" para cada pessoa. Considere a idade a partir de 18 anos como maior de idade.

*/

public class Ex18 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);

		int idade,i;

		for(i=0;i < 75;i++){
			System.out.println("Digite a idade da pessoa: ");
			idade = escreva.nextInt();

			if(idade >= 18){
				System.out.println("\nEssa pessoa eh MAIOR de idade!\n");
			}else{
				System.out.println("\nEssa pessoa eh MENOR de idade!\n");
			}
		}

	}

}