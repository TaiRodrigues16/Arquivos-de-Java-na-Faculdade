package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
31. Escrever um algoritmo que leia tr�s valores inteiros distintos e os escreva em ordem crescente.
*/

public class Ex31 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int num1,num2,num3;

		 System.out.println("Digite o primeiro numero: ");
		 num1 = escreva.nextInt();
		 System.out.println("Digite o segundo numero: ");
		 num2 = escreva.nextInt();
		 System.out.println("Digite o terceiro numero: ");
		 num3 = escreva.nextInt();

		 if((num1 < num2)&&(num1 < num3)){
		    if(num2 < num3){
		    	System.out.println("\nA ordem crescente fica: ");
		    	System.out.println(" -> " + num1);
		    	System.out.println(" -> " + num2);
		    	System.out.println(" -> " + num3);
		    }
		    else if(num2 > num3){
		    	System.out.println("\nA ordem crescente fica: ");
		    	System.out.println(" -> " + num1);
		    	System.out.println(" -> " + num3);
		    	System.out.println(" -> " + num2);
		    }
		 }
		 else if((num2 < num1)&&(num2 < num3)){
		    if(num1 > num3){
		    	System.out.println("\nA ordem crescente fica: ");
		    	System.out.println(" -> " + num2);
		    	System.out.println(" -> " + num3);
		    	System.out.println(" -> " + num1);
		    }
		    else if(num3 > num1){
		    	System.out.println("\nA ordem crescente fica: ");
		    	System.out.println(" -> " + num2);
		        System.out.println(" -> " + num1);
		        System.out.println(" -> " + num3);
		    }
		 }
		 else if((num3 < num1)&&(num3 < num2)){
		    if(num1 < num2){
		    	System.out.println("\nA ordem crescente fica: ");
		    	System.out.println(" -> " + num3);
		    	System.out.println(" -> " + num1);
		    	System.out.println(" -> " + num2);
		    }
		    else if(num1 > num2){
		    	System.out.println("\nA ordem crescente fica: ");
		    	System.out.println(" -> " + num3);
		    	System.out.println(" -> " + num2);
		    	System.out.println(" -> " + num1);
		    }
		 }

	}

}