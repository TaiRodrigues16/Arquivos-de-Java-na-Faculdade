package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
7. Ler uma temperatura em graus Celsius e apresent�-la convertida em graus Fahrenheit. A f�rmula de convers�o �:
F=(9*C+160) / 5, sendo F a temperatura em Fahrenheit e C a temperatura em Celsius.

*/

public class Ex07 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float temp,F;

		System.out.println("Digite a temperatura em Celsius: ");
		temp = escreva.nextFloat();

		F = (9 * temp + 160) / 5;

		System.out.println("\nA temperatura em Fahrenheit eh: " + F + " F");

	}

}