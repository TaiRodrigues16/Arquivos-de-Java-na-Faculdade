package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
2. Fa�a um algoritmo que receba dois n�meros e ao final mostre a soma, subtra��o, multiplica��o e a divis�o dos
n�meros lidos.
*/

public class Ex02 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float num1,num2,soma,sub,div,mult;

		System.out.println("Digite o primeiro numero: ");
		num1 = escreva.nextFloat();
		System.out.println("\nDigite o segundo numero: ");
		num2 = escreva.nextFloat();

		soma = num1 + num2;
		sub =  num1 - num2;
		mult = num1 * num2;
		div =  num1 / num2;

		System.out.println("\nO resultado da soma eh: " + soma);
		System.out.println("O resultado da subtracao eh: " + sub);
		System.out.println("O resultado da multiplicacao eh: " + mult);
		System.out.println("O resultado da divisao eh: " + div);

	}

}