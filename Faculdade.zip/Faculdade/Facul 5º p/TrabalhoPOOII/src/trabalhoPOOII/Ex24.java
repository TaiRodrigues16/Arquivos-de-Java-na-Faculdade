package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
24. Fa�a um algoritmo que receba �N� n�meros e mostre positivo, negativo ou zero para cada n�mero.
*/

public class Ex24 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int num,qtd,i;

		 System.out.println("Quantos numeros voce deseja testar? ");
		 qtd = escreva.nextInt();

		 for(i=0;i<qtd;i++){
			 System.out.println("\nDigite um numero: ");
		     num = escreva.nextInt();

		     if(num > 0){
		    	 System.out.println("Este numero eh positivo!");
		     }
		     else if(num < 0){
		    	 System.out.println("Este numero eh negativo!");
		     }
		     else if(num == 0){
		    	 System.out.println("Este numero eh igual a 0!");
		     }
		 }

	}

}