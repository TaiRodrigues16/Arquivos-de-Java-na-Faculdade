package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
29. Fa�a um algoritmo que receba o n�mero do m�s e mostre o m�s correspondente. Valide m�s inv�lido.
*/

public class Ex29 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int num;

		 System.out.println("Digite um numero referente a um mes: ");
		 num = escreva.nextInt();

		 if(num == 1){
			 System.out.println("\nMes: Janeiro");
		 }
		 else if(num == 2){
			 System.out.println("\nMes: Fevereiro");
		 }
		 else if(num == 3){
			 System.out.println("\nMes: Mar�o");
		 }
		 else if(num == 4){
			 System.out.println("\nMes: Abril");
		 }
		 else if(num == 5){
			 System.out.println("\nMes: Maio");
		 }
		 else if(num == 6){
			 System.out.println("\nMes: Junho");
		 }
		 else if(num == 7){
			 System.out.println("\nMes: Julho");
		 }
		 else if(num == 8){
			 System.out.println("\nMes: Agosto");
		 }
		 else if(num == 9){
			 System.out.println("\nMes: Setembro");
		 }
		 else if(num == 10){
			 System.out.println("\nMes: Outubro");
		 }
		 else if(num == 11){
			 System.out.println("\nMes: Novembro");
		 }
		 else if(num == 12){
			 System.out.println("\nMes: Dezembro");
		 }
		 else{
			 System.out.println("\nMes Invalido!");
		 }

	}
}