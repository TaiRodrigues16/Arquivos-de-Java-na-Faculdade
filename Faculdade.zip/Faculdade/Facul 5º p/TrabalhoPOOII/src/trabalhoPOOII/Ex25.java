package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
25. Fa�a um algoritmo que leia dois n�meros e identifique se s�o iguais ou diferentes. Caso eles sejam iguais imprima
uma mensagem dizendo que eles s�o iguais. Caso sejam diferentes, informe qual n�mero � o maior, e uma
mensagem que s�o diferentes.

*/

public class Ex25 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int num1,num2;

		 System.out.println("Digite o primeiro numero: ");
		 num1 = escreva.nextInt();
		 System.out.println("Digite o segundo numero: ");
		 num2 = escreva.nextInt();

		 if(num1 == num2){
			 System.out.println("\nEstes numeros sao iguais!");
		 }else{
			 System.out.println("\nEstes numeros sao diferentes!");

		     if(num1 > num2){
		    	 System.out.println("O numero " + num1 + " eh maior!");
		     }
		     if(num1 < num2){
		    	 System.out.println("O numero " + num2 + " eh maior!");
		     }
		 }

	}

}