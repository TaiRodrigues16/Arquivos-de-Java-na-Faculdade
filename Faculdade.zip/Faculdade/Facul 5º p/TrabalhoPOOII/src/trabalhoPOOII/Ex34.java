package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
34. A escola �APRENDER� faz o pagamento de seus professores por hora/aula. Fa�a um algoritmo que calcule e exiba o
sal�rio de um professor. Sabe-se que o valor da hora/aula segue a tabela abaixo:
Professor N�vel 1 R$12,00 por hora/aula
Professor N�vel 2 R$17,00 por hora/aula
Professor N�vel 3 R$25,00 por hora/aula

*/

public class Ex34 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int nivel, qtd;
		float salario;

		System.out.println("Digite a quantidade de aulas do professor: ");
		qtd = escreva.nextInt();
		System.out.println("Qual eh o nivel do professor: ");
		System.out.println(" 1 -> Professor Nivel 1");
		System.out.println(" 2 -> Professor Nivel 2");
		System.out.println(" 3 -> Professor Nivel 3");
		nivel = escreva.nextInt();

		if(nivel == 1){
			salario = qtd * 12;
			System.out.println("\nO salario do professor sera: " + salario + " reais.");
		}
		else if(nivel == 2){
		    salario = qtd * 17;
		    System.out.println("\nO salario do professor sera: " + salario + " reais.");
		}
		else if(nivel == 3){
		    salario = qtd * 25;
		    System.out.println("\nO salario do professor sera: " + salario + " reais");
		}
		else{
			System.out.println("\n\nEntrada de dados incorreta!\n\n");
		}
	}
}