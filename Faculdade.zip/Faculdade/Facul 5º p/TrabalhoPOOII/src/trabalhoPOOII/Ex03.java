package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
3. Escrever um algoritmo para determinar o consumo m�dio de um autom�vel sendo
fornecida a dist�ncia total percorrida pelo autom�vel e o total de combust�vel gasto.
	consumo medio = distancia / combustivel gasto       ..... km/l
*/

public class Ex03 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float dist, combus, consumo;

		System.out.println("Digite a distancia percorrida em quilometros: ");
		dist = escreva.nextFloat();
		System.out.println("\nDigite a quantidade de combustivel utilizada em litros: ");
		combus = escreva.nextFloat();

		consumo = dist / combus;

		System.out.println("\nO consumo medio eh: " + consumo + "km/l" );

	}

}