package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
6. Ler dois valores para as vari�veis A e B, e efetuar as trocas dos valores de forma que a vari�vel A passe a possuir o
valor da vari�vel B e a vari�vel B passe a possuir o valor da vari�vel A. Apresentar os valores trocados.

*/

public class Ex06 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int varA, varB, varC;

		varC = 0;

		System.out.println("Digite o valor da variavel A: ");
		varA = escreva.nextInt();
		System.out.println("Digite o valor da variavel B: ");
		varB = escreva.nextInt();

		varC = varA;
		varA = varB;
		varB = varC;

		System.out.println("\nOs valores trocados: ");
		System.out.println("Variavel A: " + varA);
		System.out.println("Variavel B: " + varB);

	}
}