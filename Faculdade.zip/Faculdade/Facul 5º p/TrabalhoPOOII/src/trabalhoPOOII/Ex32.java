package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
32. Dados tr�s valores A, B e C, em que A e B s�o n�meros reais e C � um caractere, pede-se para imprimir o resultado
da opera��o de A por B se C for um s�mbolo de operador aritm�tico; caso contr�rio deve ser impressa uma
mensagem de operador n�o definido. Tratar erro de divis�o por zero.

*/

public class Ex32 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float A,B,soma,sub,divi,mult;
		String C;

		System.out.println("Digite o primeiro numero: ");
	    A = escreva.nextFloat();
		System.out.println("Digite o segundo numero: ");
		B = escreva.nextFloat();
		System.out.println("Digite o operador aritmetico: ");
		System.out.println(" + -> Somar");
		System.out.println(" - -> Subtrair");
		System.out.println(" * -> Multiplicar");
		System.out.println(" / -> Dividir");
		C = escreva.next();
		 
		switch (C) {
		case "+":
			 soma = A + B;
			 System.out.println("\nO resultado eh: " + soma);
			 break;
		
		case "-":
			 sub = A - B;
			 System.out.println("\nO resultado eh: " + sub);
			 break;
				
		case "*":
			 mult = A * B;
			 System.out.println("\nO resultado eh: " + mult);
			 break;
				
		case "/":
			 if(B == 0){
				 System.out.println("\nN�o ha divisao por zero!");
			 }else{
		         divi = A / B;
		         System.out.println("\nO resultado eh: " + divi);
		     }
			break;

	    default:
			 System.out.println("\nOperador nao definido!");
			 break;
		}
	}
}