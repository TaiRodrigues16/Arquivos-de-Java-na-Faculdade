package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
11. Fa�a um algoritmo que receba o pre�o de custo de um produto e mostre o valor de venda. Sabe-se que o pre�o de
custo receber� um acr�scimo de acordo com um percentual informado pelo usu�rio.

*/

public class Ex11 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float precoCust, precoVenda, percent;

		System.out.println("Digite o preco de custo de seu produto: ");
		precoCust = escreva.nextFloat();

		System.out.println("Digite o valor do percentual de acrescimo: ");
		percent = escreva.nextFloat();

		precoVenda = precoCust + (precoCust * (percent / 100));

		System.out.println("\nO valor de venda do produto eh: " + precoVenda);

	}

}