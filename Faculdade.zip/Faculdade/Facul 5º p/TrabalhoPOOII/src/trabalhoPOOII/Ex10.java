package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
10. A Loja Mam�o com A��car est� vendendo seus produtos em 5 (cinco) presta��es sem juros. Fa�a um algoritmo que
receba um valor de uma compra e mostre o valor das presta��es.

*/

public class Ex10 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float valorCompra, valorPrest;

		System.out.println("Digite o valor da compra: ");
		valorCompra = escreva.nextFloat();

		valorPrest = valorCompra / 5;

		System.out.println("\nO valor de cada prestacao eh de: " + valorPrest);

	}

}