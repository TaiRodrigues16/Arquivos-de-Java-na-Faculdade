package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
36. Fa�a um algoritmo que calcule o valor da conta de luz de uma pessoa. Sabe-se que o c�lculo da conta de luz segue
a tabela abaixo:
Tipo de Cliente Valor do KW/h
1 (Resid�ncia) 0,60
2 (Com�rcio) 0,48
3 (Ind�stria) 1,29

*/

public class Ex36 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int tipoDeResidencia,qtd;
		float conta;

		 System.out.println("Qual eh o tipo de residencia: ");
		 System.out.println("1 -> Residencia");
		 System.out.println("2 -> Comercio");
		 System.out.println("3 -> Industria");
		 tipoDeResidencia = escreva.nextInt();

		 if(tipoDeResidencia == 1){
			 System.out.println("\nQual a quantidade de KW/h foram gastos? ");
		     qtd = escreva.nextInt();
		     conta = (float) (qtd * 0.60);
		     System.out.println("\nO valor da conta de energia sera: " + conta + " reais.");
		 }
		 else if(tipoDeResidencia == 2){
			 System.out.println("\nQual a quantidade de KW/h foram gastos? ");
		     qtd = escreva.nextInt();
		     conta = (float) (qtd * 0.48);
		     System.out.println("\nO valor da conta de energia sera: " + conta + " reais.");
		 }
		 else if(tipoDeResidencia == 3){
			 System.out.println("\n\nQual a quantidade de KW/h foram gastos? ");
		     qtd = escreva.nextInt();
		     conta = (float) (qtd * 1.29);
		     System.out.println("\n\nO valor da conta de energia sera: " + conta + " reais.");
		 }
		 else{
			 System.out.println("\nEntrada de dados incorreta!");
		 }
	}
}