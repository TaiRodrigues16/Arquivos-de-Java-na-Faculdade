package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
8. Elaborar um algoritmo que efetue a apresenta��o do valor da convers�o em real (R$) de um valor lido em d�lar
(US$). O algoritmo dever� solicitar o valor da cota��o do d�lar e tamb�m a quantidade de d�lares dispon�veis com o
usu�rio.
		valor dolar = R$3,83
*/

public class Ex08 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float real, dolar, conv, dolarDisp;

		System.out.println("Digite um valor em dolar: ");
		dolar = escreva.nextFloat();
		System.out.println("Digite o valor da cotacao do dolar em real: ");
		real = escreva.nextFloat();

		conv = dolar * real;

		dolarDisp = conv / dolar;

		System.out.println("\nA conversao eh: " + conv);
		System.out.println("A quantidade de dolares disponivel: " + dolarDisp);

	}

}