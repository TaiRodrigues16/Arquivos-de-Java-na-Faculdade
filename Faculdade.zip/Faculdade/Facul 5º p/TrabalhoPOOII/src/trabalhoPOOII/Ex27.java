package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
27. A concession�ria de ve�culos �CARANGO� est� vendendo os seus ve�culos com desconto. Fa�a um algoritmo que
calcule e exiba o valor do desconto e o valor a ser pago pelo cliente. O desconto dever� ser calculado sobre o valor
do ve�culo de acordo com o combust�vel (�lcool � 25%, gasolina � 21% ou diesel �14%). Com valor do ve�culo zero
encerra entrada de dados. Informe total de desconto e total pago pelos clientes.

*/ 

public class Ex27 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float valorDesc = 0, valorClient = 0,valorVeic,somaDesc,somaClient;
		String combus;

		 somaDesc = valorDesc;
		 somaClient = valorClient;

		 do{
		     System.out.println("\nDigite o valor do veiculo: ");
		     valorVeic = escreva.nextFloat();
		     System.out.println("Qual o tipo de combustivel? ");
		     System.out.println("A -> Alcool");
		     System.out.println("G -> Gaslina");
		     System.out.println("D -> Diesel");
		     combus = escreva.next();
		     
		     switch (combus) {
			 case "a":
				valorDesc = (float) (valorVeic * 0.25);
		        valorClient = valorVeic - valorDesc;
		        System.out.println("\nO valor do desconto sera de: " + valorDesc);
		        System.out.println("O valor a ser pago pelo cliente sera de: " + valorClient);
				break;
			 case "g":
				 valorDesc = (float) (valorVeic * 0.21);
		         valorClient = valorVeic - valorDesc;
		         System.out.println("\nO valor do desconto sera de: " + valorDesc);
		         System.out.println("O valor a ser pago pelo cliente sera de: " + valorClient);
				break;
			 case "d":
				 valorDesc = (float) (valorVeic * 0.14);
		         valorClient = valorVeic - valorDesc;
		         System.out.println("\nO valor do desconto sera de: " + valorDesc);
		         System.out.println("O valor a ser pago pelo cliente sera de: " + valorClient);
				break;

			 default:
				break;
			 }

		     somaDesc = somaDesc + valorDesc;
		     somaClient = somaClient + valorClient;

		 }while(valorVeic != 0);

		 System.out.println("\nO total de descontos eh: " + somaDesc);
		 System.out.println("O total pago pelos clientes eh: " + somaClient);

	}

}