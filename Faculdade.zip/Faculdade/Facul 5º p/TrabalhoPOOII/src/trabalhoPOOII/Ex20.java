package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
20. A concession�ria de ve�culos "CARANGO VELHO" est� vendendo os seus ve�culos com desconto. Fa�a um
algoritmo que calcule e exiba o valor do desconto e o valor a ser pago pelo cliente de v�rios carros. O desconto
dever� ser calculado de acordo com o ano do ve�culo. At� 2000 - 12% e acima de 2000 - 7%. O sistema dever�
perguntar se deseja continuar calculando desconto at� que a resposta seja: "(N) N�o" . Informar total de carros com
ano at� 2000 e total geral.

*/

public class Ex20 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		float valorCar, valorDes, valorTotal;
		int anoCar,cont1,cont2;
		String resp;

		cont1 = 0;
		cont2 = 0;

		resp = "s";

		while(resp != "n"){
			System.out.println("Entre com o valor do carro: ");
			valorCar = escreva.nextFloat();

			System.out.println("Entre com o ano do carro: ");
			anoCar = escreva.nextInt();

			if(anoCar <= 2000){
				valorDes = (float) (valorCar * 0.12);
				valorTotal = valorCar - valorDes;
				cont1 = cont1 + 1;
			}
			else{
				valorDes = (float) (valorCar * 0.07);
				valorTotal = valorCar - valorDes;
				cont2 = cont2 + 1;

			}

			System.out.println("\nO valor do desconto eh: " + valorDes);
			System.out.println("O valor a ser pago pelo cliente eh: " + valorTotal);
			System.out.println("\nDeseja continuar calculando o valor dos carros? ");
			System.out.println("'s' -> Sim");
			System.out.println("'n' -> Nao");
			resp = escreva.next();
			
			switch (resp) {
			case "n":
				resp = "n";
				break;
				
			case "s":
				resp = "s";
				break;
				
			default:
				break;
			}
			
		}

		System.out.println("\nO total de carros ate o ano 2000 sao: " + cont1);
		System.out.println("\nO total de carros no geral sao: " + (cont1+cont2));

	}

}