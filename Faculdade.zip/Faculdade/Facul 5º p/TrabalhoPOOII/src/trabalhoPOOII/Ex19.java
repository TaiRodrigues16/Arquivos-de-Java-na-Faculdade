package trabalhoPOOII;

import java.util.Scanner;

//Aluna: Taiane Aparecida Rodrigues      5� Per�odo de SI
/*
19. Escrever um algoritmo que leia o nome e o sexo de 56 pessoas e informe o nome e se ela � homem ou mulher. No
final informe total de homens e de mulheres.

*/

public class Ex19 {

	public static void main(String[] args) {
		Scanner escreva = new Scanner(System.in);
		int i,cont1,cont;
		String nome;
		String sexo;

		cont1 = 0;
		cont = 0;

		for(i=0;i<56;i++){
			System.out.println("\nDigite o nome da pessoa: ");
			nome = escreva.next();
			System.out.println("Digite o sexo da pessoa: (F/M)");
			sexo = escreva.next();
			
			switch (sexo) {
			case "f":
				System.out.println("\nO nome eh: " + nome + " eh feminino!\n");
				cont1 = cont1 + 1;
				break;
			case "m":
				System.out.println("\nO nome eh: " + nome + " eh masculino!");
				cont = cont + 1;
				break;

			default:
				break;
			}
		}

		System.out.println("O total de homens eh: " + cont);
		System.out.println("O total de mulheres eh: " + cont1);

	}

}