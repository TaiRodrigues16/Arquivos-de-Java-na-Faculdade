package classe;

import javax.swing.JOptionPane;

public class AgendaEx7 {
	
	static String nomePessoa[] = new String[10];
	static int idadePessoa[] = new int[10];
	static float altPessoa[] = new float[10];
	
	public static void armazenaPessoa(String nome, int idade, float altura, int pos){
		nomePessoa[pos] = nome;
		idadePessoa[pos] = idade;
		altPessoa[pos] = altura;
	}
	
	public static void removePessoa(String nome){
		int i = buscaPessoa(nome);
		if (i==10)
			i--;
		nomePessoa[i] = " ";
		idadePessoa[i] = 0;
		altPessoa[i] = 0;
	}
	
	static int buscaPessoa(String nome){
		int i;
		for (i = 0; i < 10; i++)
			if(nomePessoa[i] == nome)
				break;
		return i;
		
	}
	
	public static void imprimeAgenda(){
		String resp = " ";
		for (int i = 0; i < 10; i++) {
			resp += "Pessoa " + i + ": " + nomePessoa[i] + " - Idade: " + idadePessoa[i] + " - Altura: " + altPessoa[i] + "\n";  
		}
		
		JOptionPane.showMessageDialog(null, resp, "Agenda", 0);
	}
	
	public static void imprimePessoa(int i){
		String resp = " ";
		resp += "Pessoa " + i + ": " + nomePessoa[i] + " - Idade: " + idadePessoa[i] + " - Altura: " + altPessoa[i] + "\n";  
		JOptionPane.showMessageDialog(null, resp, "Agenda", 0);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i < 10; i++) {
			String nome = "Nome: ";
			String id = "Idade: ";
			String alt = "Altura: ";
			nome = JOptionPane.showInputDialog(nome);
			id = JOptionPane.showInputDialog(id);
			alt = JOptionPane.showInputDialog(alt);
			int idade = Integer.parseInt(id);
			float altura = Float.parseFloat(alt);
			armazenaPessoa(nome,idade,altura,i);
		}
		
		imprimeAgenda();
		
		String pos = "Qual Posi��o da agenda deseja imprimir?";
		pos = JOptionPane.showInputDialog(pos);
		int i = Integer.parseInt(pos);
		imprimePessoa(i);
		
		String nome = "Que nome deseja remover da Agenda?";
		nome = JOptionPane.showInputDialog(nome);
		removePessoa(nome);
		
		imprimeAgenda();
	}
}
