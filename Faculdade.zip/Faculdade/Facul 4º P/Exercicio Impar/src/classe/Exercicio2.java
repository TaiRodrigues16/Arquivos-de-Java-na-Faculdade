package classe;

import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int nro;
		
		System.out.println("Digite um numero inteiro: ");
		Scanner ler = new Scanner(System.in);
		
		nro = ler.nextInt();
		
		String resultado = Integer.toString(nro,2);
		System.out.println("N�mero convertido: " + resultado);
	}

}
