package classe;

import javax.swing.JOptionPane;

public class Janela {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a, b;
		String entrada1 = "Entre com o valor de A: ";
		entrada1 = JOptionPane.showInputDialog(entrada1);
		String resp = "";
		
		while(entrada1 == null || entrada1.length() == 0){
			entrada1 = "Eh preciso informar o valor de A";
			entrada1 = "A";
			entrada1 = JOptionPane.showInputDialog(entrada1);
		}
		
		a = Integer.parseInt(entrada1);
		
		String entrada2 = "Entre com o valor de B: ";
		entrada2 = JOptionPane.showInputDialog(entrada2);
		
		while(entrada2 == null||entrada2.length() == 0){
			entrada2 = "Eh preciso Informar o valor de B!";
			JOptionPane.showInputDialog(null,entrada2,"Deu Ruim!",0);
			entrada2 = "B: ";
			entrada2 = JOptionPane.showInputDialog(entrada2);
		}
		
		b = Integer.parseInt(entrada2);
		if(a < b){
			while(a < b){
				a++;
				if((a % 2 != 0)&&(a != b))
					resp = resp + a + "\n";
			}
		}
		else if(a>b){
			while(a > b){
				b++;
				if((b % 2 != 0)&&(b != 0))
					resp = resp + b + "\n";
			}
		}
		else{
			resp = "N�o h� valor entre os dois n�meros, eles s�o iguais!";
			JOptionPane.showMessageDialog(null,resp,"Resultado",0);
		}
	}

}
