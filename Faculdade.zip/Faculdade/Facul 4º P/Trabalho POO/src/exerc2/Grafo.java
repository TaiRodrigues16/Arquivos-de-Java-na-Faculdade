package exerc2;

import java.util.ArrayList;

public class Grafo {
	ArrayList<Integer>[] lista = new ArrayList[5];
	
	public Grafo() {
		for (int i = 0; i < lista.length; i++) {
			lista[i] = new ArrayList<>();
		}
		lista[0].add(1);
		lista[0].add(4);
		lista[1].add(0);
		lista[1].add(2);
		lista[1].add(3);
		lista[1].add(4);
		lista[2].add(1);
		lista[2].add(3);
		lista[3].add(1);
		lista[3].add(4);
		lista[3].add(2);
		lista[4].add(3);
		lista[4].add(0);
		lista[4].add(1);
	}
	
	public boolean verificarVizinho(int x, int y) {
		if (lista[x].contains(y)) {
			return true;
		}
		return false;
	}
	
	public int[] voltarVizinhos(int x) {
		int[] v = new int[lista[x].size()];
		for (int i = 0; i < lista[x].size(); i++) {
			v[i] = lista[x].get(i);
		}
		return v;
	}
}
