package exerc2;

import java.util.Scanner;

public class TestarGrafo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Grafo g = new Grafo();
		// Os index s�o: 0,1,2,3,4!
		System.out.println("Digite os index de quais n�meros deseja ver se s�o vizinhos: ");
		int x = sc.nextInt();
		int y = sc.nextInt();
		if (g.verificarVizinho(x, y)) {
			System.out.println("S�o vizinhos!");
		}else {
			System.out.println("N�o s�o vizinhos!");
		}
		System.out.print("Agora diga um index para verificar os vizinhos dele: ");
		x = sc.nextInt();
		int[] v = g.voltarVizinhos(x);
		for (int i = 0; i < v.length; i++) {
			System.out.println(v[i]);
		}
	}

}
