package exerc3;

import java.util.Random;

public class OrdenarVetor {

	public static void main(String[] args) {
	// Ordena��o de Vetores
    int [] vet1 = new int[50];
    int [] vet2 = new int[50]; 
    int [] vet3 = new int[vet1.length + vet2.length];
    
    int aux = 0;
    int aux2 = 0;
    
    Random gerador = new Random();
    
    for (int t = 0; t <= 49; t++)
    {
    	vet1[t] = gerador.nextInt(100);
    	//System.out.println(t + " -> " + vet1[t]);
    }

    for (int i = 0; i < vet1.length; i++)
    {
        for (int j = 0; j < vet1.length; j++)
        {
            if (vet1[i] < vet1[j])
            {
                aux = vet1[i];
                vet1[i] = vet1[j];
                vet1[j] = aux;
                //System.out.println(vet[i] + " -> Trocou!" );
            } 
        }
    }

    System.out.println(" Vetor 1 ordenado: ");
    for (int k = 0; k < vet1.length ; k++)
    {
    	System.out.println(" " + vet1[k]);
    	
    }
    System.out.println("-------------------------------------");
    
    Random gera = new Random();
    
    for (int t = 0; t <= 49; t++)
    {
    	vet2[t] = gera.nextInt(100);
    	//System.out.println(t + " -> " + vet2[t]);
    }

    for (int i = 0; i < vet2.length; i++)
    {
        for (int j = 0; j < vet2.length; j++)
        {
            if (vet2[i] < vet2[j])
            {
                aux2 = vet2[i];
                vet2[i] = vet2[j];
                vet2[j] = aux2;
                //System.out.println(vet[i] + " -> Trocou!" );
            } 
        }
    }
    System.out.println(" Vetor 2 ordenado: ");
    for (int u = 0; u < vet2.length ; u++)
    {
    	System.out.println(" " + vet2[u]);
    	 
    }
    System.out.println("-------------------------------------");
    System.out.println("Vetor 3, com as 100 posi��es j� ordenado:");
    
    int j1 = 0;
    int j2 = 0;
    for (int i = 0; i < vet1.length+vet2.length; i++) {
    	if (j1 > 49) {
    		vet3[i] = vet2[j2];
			j2++;
		}else if (j2 > 49) {
    		vet3[i] = vet1[j1];
			j1++;
		}else if (vet1[j1]<vet2[j2]) {
			vet3[i] = vet1[j1];
			j1++;
		}else {
			vet3[i] = vet2[j2];
			j2++;
		}
	}
    
    for (int i = 0; i < vet3.length; i++)
    {
        System.out.println(" " + vet3[i]);
    }
	}
}
