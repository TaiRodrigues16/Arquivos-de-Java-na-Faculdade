package exerc4;

import java.util.ArrayList;
import java.util.Scanner;

public class Pedido {
	Scanner scan = new Scanner(System.in);
	private ArrayList<Produto> itens = new ArrayList<>();

	public ArrayList<Produto> getItens() {
		return itens;
	}

	public void setItens(ArrayList<Produto> itens) {
		this.itens = itens;
	}
	
	public double precoTotalCompra(ArrayList<Produto> itens) {
		double precoTotal = 0;
		for (int i = 0; i < itens.size(); i++) {
			precoTotal += itens.get(i).getPreco();
		}
		return precoTotal;
	}
	
	public int quantidadeTotalCompra(ArrayList<Produto> itens) {
		int quantidade = 0;
		for (int i = 0; i < itens.size(); i++) {
			quantidade += itens.get(i).getQuantidade();
		}
		return quantidade;
	}
	
	public void pagamento(ArrayList<Produto> itens, int tipo) {
		double precoTotal = 0;
		int quantidade = 0;
		for (int i = 0; i < itens.size(); i++) {
			precoTotal += itens.get(i).getPreco();
			quantidade += itens.get(i).getQuantidade();
		}
		switch (tipo) {
		case 1:
			System.out.println("DIGITE SEU VALOR EM REAIS: ");
			double valor = scan.nextDouble();
			if(valor < precoTotal) {
				System.out.println("Pagamento não autorizado!");
			}else if(valor == precoTotal) {
				System.out.println("PAGAMENTO FEITO!");
				System.out.println("_______________________________");
				System.out.println("Detalhes da compra > ");
				System.out.println("Valor total: " + precoTotal);
				System.out.println("Quantidade total: " + quantidade);
				System.out.println("Tipo de pagamento: DINHEIRO ");
			}else if(valor > precoTotal) {
				System.out.println("PAGAMENTO FEITO!");
				System.out.println("_______________________________");
				System.out.println("Detalhes da compra > ");
				System.out.println("Valor total: " + precoTotal);
				System.out.println("Quantidade total: " + quantidade);
				System.out.println("Tipo de pagamento: DINHEIRO ");
				System.out.println("Troco: " + (valor - precoTotal));
			}
			break;
		
		case 2:
			System.out.println("NUMERO DE PARCELAS: ");
			int parcelas = scan.nextInt();
			System.out.println("PAGAMENTO FEITO!");
			System.out.println("_______________________________");
			System.out.println("Detalhes da compra > ");
			System.out.println("Valor total: " + precoTotal);
			System.out.println("Quantidade total: " + quantidade);
			System.out.println("Tipo de pagamento: CARTAO DE CRÉDITO ");
			System.out.println("PARCELAS: " + parcelas + "x DE " + " R$" + (precoTotal / parcelas));
			break;
			
		case 3:
			System.out.println("PAGAMENTO FEITO!");
			System.out.println("_______________________________");
			System.out.println("Detalhes da compra > ");
			System.out.println("Valor total: " + precoTotal);
			System.out.println("Quantidade total: " + quantidade);
			System.out.println("Tipo de pagamento: CHEQUE ");
			break;
			
		default:
			System.out.println("OPCAO DE PAGAMENTO INCORRETA.");
			break;
		
		}
	}
}
