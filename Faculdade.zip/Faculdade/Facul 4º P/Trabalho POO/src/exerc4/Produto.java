package exerc4;

public class Produto {

	private double preco = 0;
	private int quantidade = 0;
	
	public Produto(double p, int q) {
		this.preco = p;
		this.quantidade = q;
	}

	public Produto() {}
	
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}	
}
