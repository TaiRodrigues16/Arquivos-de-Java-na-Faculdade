package exerc4;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ArrayList<Produto> lista = new ArrayList<>();
		
		/*Cria um produto. A quantidade e os preços devem ser proporcionais 
		ex: arroz valor 14.99, quantidade 1
		arroz valor 28.98, quantidade 2
		mais vem a critério de quem está adicionando os produtos
		*/
		Produto arroz = new Produto(14.99, 1);
		Produto feijao = new Produto(9.99, 2);
		Produto batata = new Produto(3, 10);
		Produto carne = new Produto(23, 2);
		
		//adiciona um produto na lista do carrinho, pode adicionar quantos produtos quiser..
		lista.add(arroz);
		lista.add(feijao);
		lista.add(batata);
		
		//Cria um pedido e adiciona a lista de produtos nesse pedido
		Pedido pedido = new Pedido();
		pedido.setItens(lista);
		
		System.out.println("Detalhes do pedido: ");
		System.out.println("Preco total: " + pedido.precoTotalCompra(lista));
		System.out.println("Quantidade de produtos: " + pedido.quantidadeTotalCompra(lista));
		System.out.println("______________________________");
		System.out.println("FORMA DE PAGAMENTO: ");
		System.out.println("1 - DINHEIRO (Use ',' para adicionar um valor. Ex.: 99,99");
		System.out.println("2 - CARTAO ");
		System.out.println("3 - CHEQUE ");
		System.out.print(": ");
		int tipo = scan.nextInt();
		
		pedido.pagamento(pedido.getItens(), tipo);
	}

}
